Installation:
 - Extract the Zip file in your preffered folder
 - The 'assets' folder and  'drum_ru.exe' and 'saved_beats' should be in the same folder

RUN drum_ru.exe to launch the application.